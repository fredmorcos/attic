$(function(){
	console.log('loaded');
});